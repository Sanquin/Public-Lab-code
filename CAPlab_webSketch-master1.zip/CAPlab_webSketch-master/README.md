# CAPlab_webSketch
CAP laboratory website sketch

Work in Progress Aug 2019

Website intended for version control, scheduling of maintenance & general operations of Sanquin CAP laboratory.

Default: open index.html, work from there.

cheers,
Dion
