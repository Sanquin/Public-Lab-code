function addHeaders(table, keys) {
  var row = table.insertRow();
  for( var i = 0; i < keys.length; i++ ) {
    var cell = row.insertCell();
    cell.appendChild(document.createTextNode(keys[i]));
    console.log(keys[i]);
  }
}

function renderHTML(data){
  console.log(data);
  let htmlBtnStr = "";
  for(i=0; i<data.length; i++){
  //   maint_month = data[i].maint_month_1 + ' & ' + data[i].maint_month_2;
  //   htmlString += "<p>" + data[i].name + ": maintenance due in: " + maint_month + ".</p>";
    htmlBtnStr += "<button id='robot'" + [i] + "type='button' class='cust-but' onClick=''>" + data[i].name +"</button>"
  }
  document.getElementById("robot-btn").insertAdjacentHTML('beforebegin',htmlBtnStr);
    
    var table = document.createElement('table');
    for( var i = 0; i < data.length; i++ ) {
    
      var child = data[i];
      if(i === 0 ) {
        addHeaders(table, Object.keys(child));
        console.log(Object.keys(child));
      }
      var row = table.insertRow();
      Object.keys(child).forEach(function(k) {
        var cell = row.insertCell();
        cell.appendChild(document.createTextNode(child[k]));
      })
    }
    
    document.getElementById('robot-info').appendChild(table);
  }

let jsonRequest = new XMLHttpRequest();
jsonRequest.overrideMimeType("application/json");
jsonRequest.open('GET','/json/robots.json', true);
jsonRequest.onload = function(){
  let robotData = JSON.parse(jsonRequest.responseText).Robots;// console.log(robotData);
  renderHTML(robotData);
}
jsonRequest.send();


// preceding 0 when < 10
// function pad(n) {
//   return n<10 ? '0'+n : n;
// }

// alternative route

// function loadJSON(callback) {   
//     var xobj = new XMLHttpRequest();
//     xobj.overrideMimeType("application/json");
//     xobj.open('GET', '/json/robots.json', true);
//     xobj.onreadystatechange = function () {
//       if (xobj.readyState == 4 && xobj.status == "200") {
//         callback(JSON.parse(xobj.responseText));
//         // console.log(JSON.parse(xobj.responseText));
//       }
//     };
//     xobj.send(null);  
//   }
 
// loadJSON(function(json) { 
//     // console.log(json); // this will log out the json object
//   });

// document.write("<table border==\"1\"><tr>");
// for (key in data) {
//     document.write('<td>' + key + '</td>');
// }
// document.write("</tr>");
//     for (var i = 0; i < data.length; i++) {
//         document.write('<tr>');
//         for (key in data[i]) {
//         document.write('<td>' + data[i][key] + '</td>');
//         }
//             document.write('</tr>');
//     }
//     document.write("</table>");

// let months = [
//   "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
// ];
// let monthNames = [
//   "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"
// ];

// function renderHTML(data){
// console.log(data);
// let htmlBtnStr = "";
// let htmlString = "";
// for(i=0; i<data.length; i++){
//   maint_month = monthNames[data[i].maint_month];
//   htmlString += "<p>" + data[i].name + ": maintenance due in: " + maint_month + ".</p>";
//   htmlBtnStr += "<button id='robot'" + [i] + "type='button' class='cust-but' onClick=''>" + data[i].name +"</button>"
// }
// document.getElementById("robot-btn").insertAdjacentHTML('beforebegin',htmlBtnStr);
// document.getElementById("robot-info").insertAdjacentHTML('beforeend',htmlString);
// // roboContainer.insertAdjacentHTML('beforeend',htmlString);
// }
