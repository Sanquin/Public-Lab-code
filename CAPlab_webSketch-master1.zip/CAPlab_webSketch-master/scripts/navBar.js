//scroll menubar to fixed position
const nav = document.querySelector('#menubar');
const topOfNav = nav.offsetTop;

// fix nav menubar when scrolling page
function fixNav() {
 //console.log(topOfNav, window.scrollY);
 if(window.scrollY >= topOfNav) {
     document.body.style.paddingTop = nav.offsetHeight + 'px';
     document.body.classList.add('fixed-nav');
 }
 else
 {
    document.body.style.paddingTop = 0; 
    document.body.classList.remove('fixed-nav');
 }
}
window.addEventListener('scroll', fixNav);
