/*

move assays to json, read from there. CHECK!
move to XML, see how that works... 
look into async!

link JSON array objects to SVG data, addEventListener click etc...
go from there...

clean up & restructure CSS files
work on @media

Robots&Assays split SVG in separate spaces? for CSS GRID?
@media query for resizing buttons upon resizing screen.
//getting assay as objects => addeventlisteners click for svg <g> elements
// present the object data in a menu/pop up, add save as PDF/txt  add data change data: write to json.
// getting the assay object data to use in changeColors();

scripts:        <!-- async?? why?? how??--> etc...
maintenance page
<!-- make the buttons work, get data from maint_db/json. Use a form? -->
etc...
*/
