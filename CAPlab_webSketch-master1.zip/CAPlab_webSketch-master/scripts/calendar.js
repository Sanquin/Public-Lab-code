var dojoConfig = {
    async: true,
    baseUrl: '.',
    // This code registers the correct location of the "demo"
    // package so we can load Dojo from the CDN whilst still
    // being able to load local modules 
    //packages: [{
    //    name: "demo",
    //    location: location.pathname.replace(/\/[^/]*$/, '') + '/demo'
    //}]
    packages: ['dojo', 'dijit', 'dojox', 'demo']
}

// To Do:
// write input function: input to JSON/Db read/write add/delete events
// login = read/wite no login: read-only

var someData = [
  {
    id: 0,
    summary: "EVO Green Per OH",
    startTime:  new Date(2019, 7, 14, 8),
    endTime: new Date(2019, 7, 14, 12),
    calendar: "Calendar1"
  },
  {
    id: 1,
    summary: "Thuiswerk",
    startTime:  new Date(2019,7, 15, 8),
    endTime: new Date(2019,7, 15, 17),
    calendar: "Calendar2"
  }
];

require([
  "dojo/parser", 
  "dojo/ready",
  "dojox/calendar/Calendar",
  "dojo/store/Memory",
  "dojo/_base/Deferred",
  "dijit/_base/manager",
  "dojo/store/Observable",
  "dojo/domReady!"],
  function (parser, ready, Calendar, Memory, Deferred, manager, Observable) {
    ready(function(){
      calendar = new Calendar({    
        date: new Date(2019, 7, 12),
        cssClassFunc: function(item){
          return item.calendar;
        },
        store: new Observable(new Memory({data: someData})),
        dateInterval: "week",
        }, "DojoCalendar");
      }
    )}
);

//------------------------snippets etc-------------------------------------------------------------------
  // var someData = [
  //   {
  //     id: 0,
  //     summary: "Event 1",
  //     startTime:  new Date(2019,8, 1, 10),
  //     endTime: new Date(2019,8, 2, 12),
  //     calendar: "Calendar1"
  //   },
  //   {
  //     id: 1,
  //     summary: "Event 2",
  //     startTime:  new Date(2019,8, 3, 14),
  //     endTime: new Date(2019,8, 3, 16),
  //     calendar: "Calendar2"
  //   }
  // ];
  
  // calendar = new Calendar({
  //   date: new Date(2019, 8, 10),
  //   cssClassFunc: function(item){
  //     return item.calendar;
  //   },
  //   store: new Observable(new Memory({data: someData})),
  //     dateInterval: "month",
  // }, "DojoCalendar");

//   var someData = [
//     {
//       id: 0,
//       summary: "Event 1",
//       begin: new Date(2019, 0, 1, 10, 0),
//       end: new Date(2019, 0, 1, 12, 0)
//     }
//   ];
  
//  var calendar = new Calendar({
//     date: new Date(2019, 10, 10),
//     startTimeAttr: "begin",
//     endTimeAttr: "end",
//     store: new Observable(new Memory({data: someData})),
//     dateInterval: "day"
//   }, "DojoCalendar");

  // require(["dojo/ready", "dojox/calendar/Calendar", "dojo/store/JsonRest", "dojo/store/Observable"],
  //   function (ready, Calendar, JsonRest, Observable) {

  //       ready(function () {
  //           var appointmentStore = JsonRest({target: '/api/appointments'});

  //           var calendar = new Calendar({
  //               date: new Date(2008, 05, 08),
  //               dateInterval: "month",
  //               store: new Observable(appointmentStore),
  //               startTimeAttr: "start",
  //               endTimeAttr: "end",
  //               query: '?activity_type_code=ZD03',
  //               style: "position:relative;width:800px;height:500px"
  //           }, "DojoCalendar");

  //       });
  //   });

  // require([
  //   "dojox/calendar/Calendar",
  //   "dojo/store/Memory",
  //   "dojo/_base/Deferred",
  //   "dijit/_base/manager",
  //   "dojo/store/Observable",
  //   "dojo/domReady!"],
    
  //   function (Calendar, Memory, Deferred, manager, Observable) {
  //   mem = new Memory({
  //       data: [{
  //           "id": 1,
  //               "summary": "Daily Call",
  //               "startTime": new Date(2019, 2, 25, 9, 0),
  //               "endTime": new Date(2019, 2, 25, 11, 0)
  //       }]
  //   });
  //   console.log("mem is --->  " + JSON.stringify(mem));
  //   var calendar = new Calendar({
  //       dateInterval: "month",
  //       startTimeAttr: "startTime",
  //       endTimeAttr: "endTime",
  //       store: new Observable(mem)
  //   }, "DojoCalendar");
    
    
  //   calendar.startup();
  //   }
    
  //   );