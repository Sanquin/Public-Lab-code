const arrRobots = [ 'EVO28211','EVO29402','EVO23889','EVO28810','EVO30504','EVO100','EVO Blue','EVO Green', 'Starlet5617', 'STAR2915','STAR3288','Vantage1317'];
// localStorage.clear();

// to do: remove arrRobots, read from JSON/db
// generalize function for both assay- and robot-data: switch case ? 1 JSON file not 2?
// lw rwrapper data not <p> but in table, button print to PDF
// button reserve robot => save to calendar

// JSON files
const robotJSON = '/json/robots.json';
let allAssaysJSON = '/json/allAssays.json'; // be able to add/delete assays later => login => add input etc

var assayData = JSON.parse(localStorage.getItem(assayData)) || [];
let btnList= [];
let assayDataStored = assayData || [];// console.log("1: " + assayData.length)
let btnIdLastClicked; //toggleColor button
let rbtIdLastClicked; //toggleColor svg robot

document.getElementById('lw').innerHTML = "Assay data";
document.getElementById('rw').innerHTML = "Robot data";

// get JSON data and use to create HTML button elements
if(assayData.length == 0){
  jsonRequest = new XMLHttpRequest();
  jsonRequest.overrideMimeType("application/json");
  jsonRequest.open('GET',allAssaysJSON, true);
  jsonRequest.onload = () => {
      assayData = JSON.parse(jsonRequest.responseText).Assays;
      localStorage.setItem(assayDataStored, JSON.stringify(assayData));
  }
  jsonRequest.send();
};

//getting the data in & out...
assayData = JSON.parse(localStorage.getItem(assayData));
//console.log(assayData);
renderHTML(assayData, btnList);// console.log("btnList 2: " + btnList);

const assayDataHtml = document.querySelector('.assay-data');//div li left-wrapper
const robotDataHtml = document.querySelector('.robot-data');

//console.log(assayDataHtml);
//console.log(robotDataHtml);
buttonGetId(btnIdLastClicked);
robotGetId(rbtIdLastClicked);

const robotSelect = document.querySelector('.robot-select');
//robotSelect.addEventListener('click', addRobotData);

// add the assay buttons to DOM from the allAssays.json data
function renderHTML(data, btnList) {
  let htmlBtnStr = "";
  let htmlStr = "";
  for(i=0; i<data.length; i++){
    const btn = {
          name,
          htmlStr,
          isClicked: false
          }
    btn.name = data[i].name; // console.log(btn.name);
    // btn.htmlStr = `<button id='${data[i].name}' type='button' class='cust-but ${btnList.isClicked ? 'colortoggle' : ''}' onClick=getData()>${data[i].name}</button>`
    btn.htmlStr = `<button id='${data[i].name}' type='button' class='cust-but ${btnList.isClicked ? 'colortoggle' : ''}'>${data[i].name}</button>`
    btnList.push(btn);
  };
  for(i=0; i<data.length; i++){
    htmlBtnStr += btnList[i].htmlStr;
  };
  htmlBtnStr += "<button id='RESET' type='button' class='cust-but2' onClick=window.location.reload();>RESET</button>"
  document.getElementById("assay-btn").insertAdjacentHTML('beforebegin',htmlBtnStr);

  return btnList;
}

function buttonGetId(btnIdLastClicked = '') {
  let assayBtn = document.getElementsByClassName('cust-but');
  let assayBtnCount = assayBtn.length; // console.log(assayBtn);
  let lastTarget;
    for (let i = 0; i <= assayBtnCount; i += 1){
      let assaybutton = assayBtn[i] || '';
      assaybutton.onclick = function(e) {
        lastTarget = e.target;
        btnIdClicked = (this.id);
        getJsonAssayObj(btnIdClicked);//console.log(`btnList[${i}] ` + JSON.stringify(btnList[i].name));
        toggleDone(e, btnIdLastClicked);//console.log(document.querySelectorAll('.robot_select'));
        btnIdLastClicked = lastTarget;//console.log(btnIdLastClicked);
      };
    };
}

function toggleDone(e, btnIdLastClicked = '') {
  if(btnIdLastClicked != ''){
    btnIdLastClicked.classList.remove('colorToggle');
  }
  e.target.classList.add('colorToggle'); // console.log(e.target.classList.value);
}

// Get the assayID from button clicked div id
function getJsonAssayObj(assayID){
  fetch(allAssaysJSON).then(response => {
      return response.json();
      }).then(data => {// console.log(data.Assays);
          let assayObject = [];
          let searchField = "name";
          let searchVal = assayID;// console.log(searchVal);
          for (let i=0 ; i < data.Assays.length ; i++)
          {
            if (data.Assays[i][searchField] == searchVal) {
                assayObject.push(data.Assays[i]); //console.log("getJsonAssayObj: " + data.Assays[i].name);// console.log("assayObject [0] : " + assayObject[0]);
                changeColors(data.Assays[i]);
                assayObject = Array.from((assayObject));
                populateAssayData(assayObject);
            }
          }
      // })
      // .catch(err => {
      // console.log('The request failed!'); 
  });
}

// click assay button, assign color to robots that perfrom assay
function changeColors(assayObj){
  for(i = 0; i < assayObj.robotArray.length; i++){
      let assayElement = document.getElementById(arrRobots[i]);// 
      //let assayElement = document.getElementById(assayObj.name);// 
      console.log(assayElement);
    for(j = 0; j < assayElement.childElementCount; j++){
      if(assayObj.robotArray[i]){
          assayElement.children[j].setAttribute('style', 'background: rgb(170, 198, 221)');
          assayElement.classList.add('robot_select');// console.log(assayElement.children[j]);
      }
      else
      {
          assayElement.children[j].setAttribute('style', 'fill:  rgb(41, 41, 41)');
          assayElement.classList.remove('robot_select');
      }
    }
  }
}

function populateAssayData(assayObj) {
  assayDataHtml.innerHTML = assayObj.map((assayDat) => {
    return `
      <p>
        <p>Assay Data</p> 
        <p>Assayname: ${assayDat.name}</p> 
        <p>Antibody:  ${assayDat.aBname}</p>
        <p>Clis ID:   ${assayDat.ClisId}</p>
      </p>
      `;
  }).join(''); // switch to table TH tr td etc...
}


//---------------below is work in progress, working but looking for improvement and extended functionality ------------------------------------------------------------------------

//robotGetId(rbtIdLastClicked);

function robotGetId(rbtIdLastClicked = '') {
  let rbtBtn = document.getElementsByClassName('robot'); // && <g id='robotID' class='robot'> &&  .contains robot-class
  let rbtBtnCount = rbtBtn.length; // console.log(rbtBtn);
  console.log('robot button clicked: ' + rbtBtn.length);
  let lastTarget;
    for (let i = 0; i <= rbtBtnCount; i += 1){
      let robot = rbtBtn[i] || '';//console.log(rbtBtn[i].childNodes);
      robot.onclick = function(e) {
        lastTarget = e.target;
        rbtIdClicked = (this.id);//console.log(rbtIdClicked);
        getJsonRobotObj(rbtIdClicked);//console.log(`btnList[${i}] ` + JSON.stringify(btnList[i].name));
        toggleDone(e, rbtIdLastClicked);//console.log(document.querySelectorAll('.robot_select'));
        rbtIdLastClicked = lastTarget;//console.log(btnIdLastClicked);
      };
    };
}


//sopmething to fix.... colorToggle added to childnode rect, but not when selected...
function toggleDone(e, btnIdLastClicked = '') {
  if(btnIdLastClicked != ''){
    btnIdLastClicked.classList.remove('colorToggle');
  }
  e.target.classList.add('colorToggle'); // console.log(e.target.classList.value);
}

//robotDataHtml = document.querySelector('.robots');
// Get the robotID from JSON
function getJsonRobotObj(robotID){
  fetch(robotJSON).then(response => {
      return response.json();
      }).then(data => {//console.log(data.Robots);
          let robotObject = [];
          let searchField = "name";
          let searchVal = robotID;// console.log(searchVal);
          let selectedElement = document.getElementById(robotID);//console.log(selectedElement);
          for (let i=0 ; i < data.Robots.length ; i++)
          {
            // only change data when robot that is in classList colorToggle && robot_select.
            // if (data.Robots[i][searchField] == searchVal) {
            if (data.Robots[i][searchField] == searchVal && selectedElement.classList.contains('robot_select')){
                robotObject.push(data.Robots[i]);//console.log("getJsonRobotObj: " + JSON.stringify(data.Robots[i]));
                robotObject = Array.from((robotObject));//console.log("robotObject : " + robotObject);
                populateRobotData(robotObject);
            }
          }
      })
      .catch(err => {
      console.log('The request failed!'); 
  });
}

function populateRobotData(robotObj) {
  robotDataHtml.innerHTML = robotObj.map((robotDat) => {
    // console.log(robotDataHtml.innerHTML);
    return `
      <p>
        <p>Robot Data</p> 
        <p>Brand:           ${robotDat.brand}</p> 
        <p>Name:            ${robotDat.name}</p> 
        <p>Location:        ${robotDat.location}</p>
        <p>Serial:          ${robotDat.serial}</p> 
        <p>IP-address:      ${robotDat.IP}</p> 
        <p>Sqn-number:      ${robotDat.sqn_nr}</p>
        <p>1st maintenance: ${robotDat.maint_month_1}</p>
        <p>2nd maintenance: ${robotDat.maint_month_2}</p>
      </p>
      `;
  }).join('');
  console.log(robotDataHtml.innerHTML); // switch to table TH tr td etc...
}

//------------------------------------snippets below-----------------------------

/* 
robot data left
queryselector all robot_select mousedown/click => get robot ID svg id => get robot data 

click assay
assaydata right=

data to screen example template string literals
  const markup = `
    <div class="person">
      <h2>
        ${person.name}
        <span class="job">${person.job}</span>
      </h2>
      <p class="location">${person.city}</p>
      <p class="bio">${person.bio}</p>
    </div>
  `;

  console.log(markup);
  document.body.innerHTML = markup;

  const dogs = [
    { name: 'Snickers', age: 2 },
    { name: 'Hugo', age: 8 },
    { name: 'Sunny', age: 1 }
  ];

  const markup = `
    <ul class="dogs">
      ${dogs.map(dog => `
        <li>
          ${dog.name}
          is
          ${dog.age * 7}
        </li>`).join('')}
    </ul>
  `;
  document.body.innerHTML = markup;

IF null/empty turnary statement 
    const song = {
    name: 'Dying to live',
    artist: 'Tupac',
    featuring: 'Biggie Smalls'
  };

  const markup = `
    <div class="song">
      <p>
        ${song.name} — ${song.artist}
        ${song.featuring ? `(Featuring ${song.featuring})` : ''}
      </p>
    </div>
  `;

  document.body.innerHTML = markup;

render function
  const beer = {
    name: 'Belgian Wit',
    brewery: 'Steam Whistle Brewery',
    keywords: ['pale', 'cloudy', 'spiced', 'crisp']
  };

  function renderKeywords(keywords) {
    return `
      <ul>
        ${keywords.map(keyword => `<li>${keyword}</li>`).join('')}
      </ul>
    `;
  }

  const markup = `
    <div class="beer">
      <h2>${beer.name}</h2>
      <p class="brewery">${beer.brewery}</p>
      ${renderKeywords(beer.keywords)}
    </div>
  `;
*/


// Sanitize data input
// function sanitize(strings, ...values) {
//   const dirty = strings.reduce((prev, next, i) => `${prev}${next}${values[i] || ''}`, '');
//   return DOMPurify.sanitize(dirty);
// }


// see how to use this later...
// filter EVO name's /robot names
// const category = document.querySelector('.wrapper');
// const links = Array.from(category.querySelectorAll('g'));
// const arrRobots = links
//             .map(link => link.id)
//             .filter(iD => iD.includes('EVO'));
//             console.log(arrRobots);

// JSON fetch data!
// fetch('./json/allAssays.json').then(response => {
//     return response.json();
//     }).then(data => {
//         console.log(data.Assays);
//         var assayObject = [];
//         var searchField = "name";
//         var searchVal = "aC1inh";
//         for (var i=0 ; i < data.Assays.length ; i++)
//         {
//             if (data.Assays[i][searchField] == searchVal) {
//                 assayObject.push(data.Assays[i]);
//                 console.log(data.Assays[i]);
//                 console.log(assayObject);
//             }
//         }
//     }).catch(err => {
//     console.log('The request failed!'); 
// });